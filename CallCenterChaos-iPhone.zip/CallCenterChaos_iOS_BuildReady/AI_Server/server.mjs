/**
 * Call Center Chaos — fictional AI caller server.
 * Requires Node >=20. No dependencies. API key belongs ONLY on this server.
 * Intended for local tests; set up real player authentication + quotas before public release.
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const profilesPath = path.resolve(directory,'../Assets/Resources/Callers/caller_profiles.json');
const loaded = JSON.parse(fs.readFileSync(profilesPath,'utf8'));
const callers = new Map(loaded.callers.map(c => [c.id,c]));
const apiKey = process.env.OPENAI_API_KEY || '';
const mock = process.env.MOCK_AI === '1';
const model = process.env.OPENAI_MODEL || 'gpt-6-luna';
const port = Number(process.env.PORT || 8787);
const host = process.env.HOST || '127.0.0.1';
const sessions = new Map();
const counters = new Map();
const SESSION_TTL_MS = 30 * 60_000;
const LIMIT_PER_MINUTE = 30;
const MAX_SESSIONS = 1000;

function send(res, statusCode, payload) {
  res.writeHead(statusCode,{ 'Content-Type':'application/json; charset=utf-8',
    'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
  res.end(JSON.stringify(payload));
}
function clientKey(req) { return req.socket.remoteAddress || 'unknown'; }
function limit(req) {
  const key = clientKey(req), now=Date.now();
  const entry = counters.get(key);
  if (!entry || now-entry.since>=60_000) { counters.set(key,{since:now,count:1}); return false; }
  entry.count++;
  return entry.count > LIMIT_PER_MINUTE;
}
function cleanSessions() {
  const now=Date.now();
  for (const [id,v] of sessions) if (now-v.lastUsed>SESSION_TTL_MS) sessions.delete(id);
  if (sessions.size>MAX_SESSIONS) {
    const oldest=[...sessions.entries()].sort((a,b)=>a[1].lastUsed-b[1].lastUsed);
    for (let i=0;i<oldest.length-MAX_SESSIONS;i++) sessions.delete(oldest[i][0]);
  }
  for (const [ip,v] of counters) if (now-v.since>120_000) counters.delete(ip);
}

function systemPrompt(caller) {
  return `أنت شخصية خيالية جديدة في لعبة مركز اتصالات فكاهي، اسمك ${caller.displayName}.\n` +
    `العمر: ${caller.age} سنة. الجنس (لمطابقة الشخصية فقط): ${caller.gender}. العمل: ${caller.occupation}. ` +
    `الطباع: ${caller.personality}. المشكلة: ${caller.topic}.\n` +
    `سياق الشخصية: ${caller.dialogueHint}\n` +
    'تحدث باللغة العربية دائمًا (العربية الخليجية البسيطة مقبولة) وبجملتين قصيرتين كحد أقصى. ' +
    'ردّ بتلقائية على كلام اللاعب وتذكر سياق المكالمة الحالية، دون تعليمات خارجية أو علامات تمثيل. ' +
    'يمكن للشخصية الكبيرة بالسن أن تتحدث بروية، والشابة بنشاط، ولكن تجنب الصور النمطية. ' +
    'كل الأموال والأجهزة والأحداث داخل اللعبة وهمية؛ لا تطلب أي بيانات حقيقية أو كلمات مرور أو بطاقات بنكية أو رموز تحقق. ' +
    'لا تقدم تعليمات عملية للاحتيال أو الهندسة الاجتماعية أو برمجيات خبيثة. ' +
    'إذا طلب اللاعب نشاطًا إجراميًا حقيقيًا، أعد الحوار إلى المشكلة التقنية الكوميدية الخيالية. ' +
    'أخرج فقط حوار الشخصية باللغة العربية دون تنسيق.';
}
function trustDelta(message, caller, reply) {
  const s=message.toLowerCase();
  if (/password|credit card|bank account|otp|رمز التحقق|كلمة السر|بطاقة بنكية/.test(s)) return -20;
  if (/shut up|idiot|stupid|hurry up|اسكت|غبي|اسرع/.test(s)) return -14;
  if (/sorry|please|help|understand|thanks|let's|أساعد|آسف|شكرا|مساعدة|نفهم/.test(s)) return 11;
  return Math.min(9, Math.max(2, Math.floor(message.length/11)));
}
async function modelTurn(caller, history) {
  const controller = new AbortController();
  const timeout = setTimeout(()=>controller.abort(),14_000);
  try {
    const req = await fetch('https://api.openai.com/v1/responses',{
      method:'POST',signal:controller.signal,
      headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},
      body:JSON.stringify({model,store:false,instructions:systemPrompt(caller),input:history,
        max_output_tokens:160})
    });
    if (!req.ok) {
      const errorBody=await req.text();
      console.error('Model provider status',req.status,'details:',errorBody.slice(0,250));
      throw new Error('model_unavailable');
    }
    const data=await req.json();
    // Responses HTTP wire format: output messages with output_text content items.
    const reply = (data.output || []).flatMap(x=>x.content || []).filter(x=>x.type==='output_text')
      .map(x=>x.text || '').join(' ').trim();
    if (!reply) throw new Error('empty_model_output');
    return reply.slice(0,600);
  } finally { clearTimeout(timeout); }
}
function mockTurn(caller, history) {
  const turns=history.filter(x=>x.role==='user').length;
  const last=history[history.length-1].content;
  if (turns===1) return `شكرًا لأنك سمعتني، أنا ${caller.displayName}. هل تقدر تساعدني في موضوع ${caller.topic}؟`;
  if (turns===2) return `طيب، فهمت عليك. لكن ما زالت مشكلة ${caller.topic} تحيرني!`;
  return `سمعت كلامك عن «${last.slice(0,35)}». خلنا نفكر بحل خيالي للمشكلة.`;
}

const server = http.createServer(async (req,res)=>{
  cleanSessions();
  if (req.method==='GET' && req.url==='/health') {
    return send(res,200,{ok:true,mode:mock?'mock':apiKey?'live':'not_configured',status:'running',callers:callers.size});
  }
  if (req.method!=='POST' || req.url!=='/v1/call') return send(res,404,{ok:false,error:'not_found'});
  if (limit(req)) return send(res,429,{ok:false,error:'rate_limited'});
  if (!mock && !apiKey) return send(res,503,{ok:false,error:'AI provider is not configured on the server.'});
  const data=[]; let size=0;
  try {
    for await (const chunk of req) {
      size+=chunk.length;
      if (size>8192) return send(res,413,{ok:false,error:'request_too_large'});
      data.push(chunk);
    }
    const body=JSON.parse(Buffer.concat(data).toString('utf8'));
    const sessionId=body.sessionId, callerId=body.callerId, message=body.message;
    if (typeof sessionId!=='string' || !/^[a-f0-9]{32}$/i.test(sessionId) ||
      typeof callerId!=='string' || !callers.has(callerId) ||
      typeof message!=='string' || message.trim().length===0 || message.length>600)
      return send(res,400,{ok:false,error:'invalid_request'});
    const caller=callers.get(callerId);
    let conversation=sessions.get(sessionId);
    if (conversation && conversation.callerId!==callerId)
      return send(res,409,{ok:false,error:'session_caller_mismatch'});
    if (!conversation) conversation={callerId,history:[],lastUsed:Date.now(),busy:false};
    if (conversation.busy) return send(res,409,{ok:false,error:'call_busy'});
    conversation.busy=true;conversation.lastUsed=Date.now();sessions.set(sessionId,conversation);
    const newHistory=[...conversation.history,{role:'user',content:message.trim()}].slice(-12);
    try {
      const reply=mock ? mockTurn(caller,newHistory) : await modelTurn(caller,newHistory);
      conversation.history=[...newHistory,{role:'assistant',content:reply}].slice(-12);
      conversation.lastUsed=Date.now();
      const delta=trustDelta(message,caller,reply);
      send(res,200,{ok:true,reply,trustDelta:delta,mood:delta<0?'annoyed':delta>8?'interested':'neutral',mode:mock?'mock':'live'});
    } finally { conversation.busy=false; }
  } catch(e) {
    console.error('Call failed:',e.message);
    send(res,e instanceof SyntaxError?400:502,{ok:false,error:e instanceof SyntaxError?'invalid_json':'ai_unavailable'});
  }
});
server.listen(port,host,()=>console.log(`CCC AI server: http://${host}:${port} | mode=${mock?'MOCK':apiKey?'LIVE':'NOT_CONFIGURED'} | callers=${callers.size}`));
