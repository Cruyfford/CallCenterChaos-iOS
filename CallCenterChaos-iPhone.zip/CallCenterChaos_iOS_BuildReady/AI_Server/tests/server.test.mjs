import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {randomBytes} from 'node:crypto';

async function withServer(env, run) {
  // Bind only on localhost; no model API network calls in these tests.
  const port = 18000 + Math.floor(Math.random()*20000);
  const server=spawn(process.execPath,['server.mjs'],{
    cwd:new URL('..',import.meta.url),
    env:{...process.env, PORT:String(port),HOST:'127.0.0.1', ...env},
    stdio:['ignore','pipe','pipe']});
  let err='';
  server.stderr.on('data',x=>{err+=x.toString()});
  try {
    let ok=false;
    for(let i=0;i<45;i++) {
      if(server.exitCode!==null)break;
      try { const r=await fetch(`http://127.0.0.1:${port}/health`);if(r.ok){ok=true;break;} }catch{}
      await delay(70);
    }
    assert.ok(ok,'server did not start: '+err);
    await run(`http://127.0.0.1:${port}`);
  }finally {server.kill('SIGTERM');}
}

const sid=()=>randomBytes(16).toString('hex');
const send=(base,payload)=>fetch(base+'/v1/call',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});

test('144 original Arabic profiles, live-mode disabled without a key', async()=> {
  await withServer({MOCK_AI:'0',OPENAI_API_KEY:''},async base=>{
    const health=await(await fetch(base+'/health')).json();
    assert.equal(health.callers,144);assert.equal(health.mode,'not_configured');
    const r=await send(base,{sessionId:sid(),callerId:'CALLER_001',message:'أهلًا'});
    assert.equal(r.status,503);
  });
});

test('Arabic fictional-character mock speaks Arabic and isolates callers',async()=>{
  await withServer({MOCK_AI:'1',OPENAI_API_KEY:''},async base=>{
    const id=sid();
    const a=await send(base,{sessionId:id,callerId:'CALLER_001',message:'أهلاً، هل تحتاج مساعدة؟'});
    assert.equal(a.status,200);const data=await a.json();
    assert.equal(data.ok,true);assert.equal(data.mode,'mock');
    assert.match(data.reply,/مريم الهاشمي/);
    assert.match(data.reply,/[\u0600-\u06ff]/);
    const b=await send(base,{sessionId:id,callerId:'CALLER_001',message:'سأشرح لك حل المشكلة'});
    assert.equal(b.status,200);const d=await b.json();
    assert.match(d.reply,/فهمت عليك/);
    const wrong=await send(base,{sessionId:id,callerId:'CALLER_002',message:'مرحبًا'});
    assert.equal(wrong.status,409);
  });
});

test('rejects untrusted invalid profile and session IDs',async()=>{
  await withServer({MOCK_AI:'1',OPENAI_API_KEY:''},async base=>{
    const r=await send(base,{sessionId:'x',callerId:'CALLER_999',message:'اختبار'});
    assert.equal(r.status,400);
  });
});
