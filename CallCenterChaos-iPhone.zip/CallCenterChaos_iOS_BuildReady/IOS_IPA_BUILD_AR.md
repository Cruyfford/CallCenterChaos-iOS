# تحويل Call Center Chaos إلى IPA (iPhone)

هذه النسخة تضيف **ملفات بناء قابلة للتنفيذ عند توفر بيئة البناء**؛ لا تحتوي على IPA جاهز. المشروع مبني على Unity 2022.3.62f1 ويحتاج دعم منصة iOS.

## أفضل طريقة بدون Mac خاص بك — GitHub Actions

1. ارفع **محتويات** مجلد `CallCenterChaos_iOS_BuildReady` إلى مستودع GitHub جديد مخصص لهذه اللعبة (وليس مشروع Velmira Play).
2. في إعدادات المستودع: **Settings → Secrets and variables → Actions**؛ أضف بيانات تفعيل Unity الصحيحة. حسب نوع الترخيص قد تحتاج `UNITY_LICENSE` (ترخيص Unity Personal مفعّل) أو `UNITY_EMAIL` و`UNITY_PASSWORD` و`UNITY_SERIAL` (Pro). لا ترسل كلمات السر في محادثة عامة، ولا تحفظها في الملفات.
3. من **Actions → iOS unsigned IPA (Unity + Xcode) → Run workflow** لتشغيل تصدير Unity ثم تجميع Xcode.
4. إذا نجح العمل، حمّل `CallCenterChaos-UNSIGNED-IPA` من Artifacts. هو **غير موقّع**، ولذلك ليس قابلًا للتثبيت على iPhone العادي حتى توقّعه بإجراءات iOS صحيحة.

> تنبيه: هذا الـWorkflow ملف تحضير ولم يُشغّل في هذه الجلسة. قد يفشل إن لم يُقبل ترخيص Unity، أو لم تتوفر نسخة دعم iOS من Unity في عامل GitHub، أو حدثت أخطاء تجميع لم تظهر قبل الاختبار.

## البناء على Mac

1. افتح المجلد في Unity 2022.3.62f1 مع iOS Build Support، وسجّل الدخول إلى Unity.
2. بدّل المنصة إلى iOS، ثم من **Tools → Call Center Chaos → Create Playable Scene** لتوليد مشهد.
3. أنشئ تصدير Xcode من Unity أو استعمل الأمر `-batchmode -quit -buildTarget iOS -projectPath <المشروع> -executeMethod CCCBuildIOS.Export -logFile <log>` مع مسار Unity Editor الصحيح.
4. افتح `build/iOS/CallCenterChaos/Unity-iPhone.xcodeproj` باستخدام Xcode. اختر Development Team وتفعيل Signing على جهاز iPhone مسجل باسمك، ثم Build.
5. لعمل نسخة IPA موقّعة للتثبيت/التوزيع، استخدم Xcode Archive ثم Distribute App وفق ملف تعريف التوقيع المناسب. سكربت `Tools/package_unsigned_ipa.sh` يصدر **IPA غير موقّع** فقط.

## ملاحظات مهمة

- لا يمكن تحويل ZIP إلى IPA بمجرد إعادة تسمية الملف: يجب تجميع Unity وXcode فعلًا.
- المحادثات الحقيقية تحتاج خادم HTTPS ومفتاح API محفوظًا على الخادم، ولا تعمل بمجرد تثبيت IPA.
- المشروع ما يزال **نموذجًا تجريبيًا** ولم يختبر على iPhone أو بخوادم AI حقيقية. لا يتضمن لعبًا متعدد المستخدمين أونلاين.
- أذونات الميكروفون والتعرف على الكلام تضاف عبر `Assets/Scripts/Editor/iOSSetup.cs` بعد تصدير Unity.
- فيديوهات وموديلات اللعبة التجارية الأصلية ليست ضمن هذه الحزمة.
