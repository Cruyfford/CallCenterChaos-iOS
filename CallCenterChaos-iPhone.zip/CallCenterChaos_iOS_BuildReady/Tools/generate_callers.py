#!/usr/bin/env python3
"""Original stylized caller illustrations + deterministic Unity-ready profile JSON.
No copyrighted game assets or likenesses are copied.
"""
from pathlib import Path
import json, random, math, colorsys, hashlib, textwrap
import cairosvg

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'Assets'/'Resources'/'Callers'
PORTRAITS = BASE/'Portraits'
PORTRAITS.mkdir(parents=True,exist_ok=True)
FIRST = ['Maya','Owen','Zara','Felix','Amara','Jonah','Talia','Hugo','Nadia','Basil','Mina','Elias']
LAST = ['Bluebell','Marsh','Lantern','Foxley','Rivers','Quill','Clover','Comet','Harbor','Orchid','Wilder','Piper']
JOBS = ['amateur astronomer','dog walker','toy museum guide','puzzle maker','park gardener','comic book seller','cookie baker','radio host','aquarium volunteer','street musician','bookshop clerk','train enthusiast','mushroom photographer','miniature sculptor','meteorologist','museum archivist','puppet maker','roller-skating coach']
PERSONALITIES = ['skeptical','cheerful','anxious','talkative','impatient','curious','shy','dramatic','witty','serious','confused','optimistic','mysterious','sleepy','perfectionist','friendly','stubborn','nervous']
PROBLEMS = [
 ('My digital cactus keeps emailing me postcards.','cactus postcards'),
 ('The music player insists every song is a kazoo solo.','kazoo music'),
 ('A virtual pigeon has moved into my desktop.','desktop pigeon'),
 ('My weather widget predicts jellybean storms.','jellybean weather'),
 ('The cursor is wearing a tiny hat and refusing to move.','tiny cursor hat'),
 ('My virtual pet has ordered forty imaginary pizzas.','virtual pet pizza'),
 ('I think the calendar scheduled Wednesday twice.','double Wednesday'),
 ('The printer keeps drawing portraits of my cat.','printer cat art'),
 ('The clock app claims I live on the moon.','moon clock'),
 ('My wallpaper turns into a disco ball at noon.','disco wallpaper'),
 ('Every folder on my computer is named banana.','banana folders'),
 ('I lost a fictional trophy inside my shopping list.','missing trophy'),
 ('My game character walks backward only.','backward avatar'),
 ('The recipe app tells me to bake snowflakes.','snowflake recipe'),
 ('The keyboard plays a trumpet sound on every key.','trumpet keyboard'),
 ('My virtual greenhouse is full of dancing tomatoes.','dancing tomatoes'),
 ('A cartoon spaceship landed in my inbox.','spaceship inbox'),
 ('The alarm keeps announcing it is my birthday.','birthday alarm')
]
MOODS = [
 'I like a careful explanation.', 'Please keep it simple for me.',
 'I have a few minutes, so make it fun.', 'I am not convinced this will work.',
 'My friends think this is hilarious.', 'I would rather solve it myself.',
 'I am happy to hear a sensible plan.', 'This has been a truly peculiar day.'
]
COLORS = ['#e96958','#edac54','#71b8c1','#7f8ac7','#94b78e','#b58ac5','#c16c91','#52a2a0','#c78756','#94add2','#b1a269','#bf7e7d']
SKIN = ['#f5d7bc','#efb88d','#d98d60','#a96846','#794b36','#e3ab78','#bd7556','#f2c4a0','#8c543d','#c98a62','#e0a875','#ab6c47']
HAIR = ['#26242c','#362322','#51352e','#744735','#966b3c','#d0ad70','#4f485d','#a85839','#c7a46b','#251d27','#3d3e45','#a98d78']
EYE = ['#252b35','#4f3627','#2c5161','#406143']

def rgb(hexcolor):
 h=hexcolor.lstrip('#');return tuple(int(h[i:i+2],16) for i in (0,2,4))
def shade(hexcolor,k):
 a=rgb(hexcolor);return '#%02x%02x%02x'%tuple(max(0,min(255,int(v*k))) for v in a)
def lighten(hexcolor,k=.32):
 a=rgb(hexcolor);return '#%02x%02x%02x'%tuple(min(255,int(v+(255-v)*k)) for v in a)
def linepath(d,fill,stroke='#302938',w=5): return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round"/>'
def ellipse(cx,cy,rx,ry,fill,stroke='#302938',w=5):return f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{fill}" stroke="{stroke}" stroke-width="{w}"/>'

# Arabic-first original callers: 72 women, 72 men; 48 are 60+ (24 women, 24 men).
FIRST_F = ['مريم','فاطمة','نورة','سارة','ليلى','هند','جواهر','زينب','ريم','عائشة','أمل','لطيفة']
FIRST_M = ['خالد','يوسف','عمر','راشد','عبدالله','علي','حسن','سالم','جاسم','فهد','ناصر','ماجد']
FAMILIES = ['الهاشمي','العتيبي','الكعبي','المهندي','العصفور','الزيد','البوعينين','العوضي','الشريف','البحري','الموسوي','الناصر']
JOBS_AR = ['معلمة متقاعدة','موظف بريد','مهندسة','صانع ألعاب','صاحبة متجر','مصور','مذيعة','مزارع','أستاذة','مؤلف قصص','مكتبية','خبير أرصاد','موظفة متحف','طاهٍ','ممرضة','فنانة','مصلّح أجهزة','موسيقي']
PERSONALITIES_AR = ['هادئة','فضولية','مرحة','متشككة','سريعة الغضب','اجتماعية','قلقة','صبورة','درامية','ذكية','خجولة','متفائلة']
PROBLEMS_AR = [
 'الساعة الذكية تتحدث عن القمر','الطابعة ترسم قططًا بدل الفواتير','التطبيق يبدل الألوان كل ساعة',
 'التقويم يضيف يومًا خياليًا','نباتي الرقمي يرسل رسائل غريبة','زر التشغيل يخرج صوت مزمار',
 'حاسوب الألعاب يعرض طيورًا راقصة','البريد الإلكتروني امتلأ بالبالونات','المتجر الافتراضي يبيع غيومًا',
 'المساعد الآلي يقول إن اليوم عيد ميلادي','الفأرة تتحرك وحدها في اللعبة','الشاشة تعرض أمطارًا من الحلوى',
 'الصور تختفي داخل مجلد موز','الموسيقى تتحول إلى أصوات مضحكة','روبوت المطبخ يطبخ ثلجًا',
 'ساعتي تتأخر عامًا كاملًا','لعبتي تضع اللاعب بالمقلوب','الروبوت يرفض تنظيف المكتب'
]

def generate_profile(i):
 r=random.Random(510351+i*997)
 female=(i%2 == 0)
 senior=(i%3 == 0)
 person_index=i//2
 first=(FIRST_F if female else FIRST_M)[person_index%12]
 last=FAMILIES[person_index//12]
 name=first+' '+last
 gender='female' if female else 'male'
 age=r.randint(62,85) if senior else r.randint(19,55)
 topic=PROBLEMS_AR[(i*7+person_index//12)%len(PROBLEMS_AR)]
 personality=PERSONALITIES_AR[(i*11+person_index//12)%len(PERSONALITIES_AR)]
 job=JOBS_AR[(i*5+person_index//12)%len(JOBS_AR)]
 skin=(i*7+person_index//12)%12
 hair=(i*5+person_index%12)%12
 clothing=(i*11+person_index//12)%12
 hstyle=(i*7+person_index%12+person_index//12)%13
 eyewear=senior or ((i*3+person_index//12)%11 in [0,1,2,3])
 hat=(not female) and ((i*5+person_index//12)%13 in [1,2,3])
 hijab=female and ((person_index*7+3)%5==0)
 beard=(not female) and (((i*7+person_index)%12 in [0,3,8]) or (senior and i%4==1))
 earrings=female and not hijab and i%4 != 1
 freckles=(i*3+person_index//12)%7 in [1,2]
 mustache=(not female) and ((i*5+person_index//12)%16 in [0,1] or senior)
 shape=(i*13+person_index//12)%7
 nose=(i*2+person_index//12)%4
 eye=(i*3+person_index//12)%5
 jacket=(i*7+person_index//12)%5
 accessory=(i*13+person_index//12)%8
 # Pitch/rate preferences give each ID a stable vocal timbre, not 144 unique recordings.
 pitch=round(r.uniform(.93,1.17) if female else r.uniform(.79,1.03), 3)
 if senior: pitch=round(pitch*.92,3)
 rate=round(r.uniform(.44,.54) if not senior else r.uniform(.36,.45),3)
 greeting=f'أهلًا، معك {name}. عندي مشكلة غريبة: {topic}. هل تستطيع مساعدتي؟'
 return {
  'id':f'CALLER_{i+1:03}', 'displayName':name, 'portrait':f'Callers/Portraits/caller_{i+1:03}',
  'gender':gender, 'age':age, 'ageGroup':'senior' if senior else 'adult',
  'language':'ar-SA','voiceVariant':int((i*7+person_index//12)%10),
  'voicePitch':pitch,'voiceRate':rate,
  'personality':personality, 'occupation':job, 'topic':topic,
  'greeting':greeting,
  'dialogueHint':f'هذه شخصية خيالية باللغة العربية اسمها {name}، عمرها {age}، مهنتها {job}، طباعها {personality}، ومشكلتها التقنية الخيالية: {topic}.',
  'highTrustReply':f'ممتاز! يبدو أنك فهمت مشكلة {topic}، أشكرك كثيرًا.',
  'mediumTrustReply':f'فهمت عليك قليلًا، لكن ماذا نفعل بشأن {topic}؟',
  'lowTrustReply':f'لا أشعر بالراحة في هذه المكالمة، أريد إنهاءها الآن.',
  'patience':r.randint(25,92),
  '_art':{'skin':skin,'hair':hair,'clothing':clothing,'hstyle':hstyle,'eyewear':eyewear,'hat':hat,
          'hijab':hijab,'female':female,'senior':senior,'beard':beard,'earrings':earrings,
          'freckles':freckles,'mustache':mustache,'age':age,'shape':shape,'nose':nose,'eye':eye,
          'jacket':jacket,'accessory':accessory,'seed':i}
 }

def render_svg(p):
 a=p['_art'];r=random.Random(18+a['seed']*23)
 bg=COLORS[(a['seed']*5+a['shape'])%12];color=COLORS[a['clothing']];skin=SKIN[a['skin']];hair=HAIR[a['hair']]
 if a['senior']:
  hair=['#d5d4cf','#aeb2b8','#e6e5d8','#838592','#c4bcb6'][a['seed']%5]
 sw=6;parts=[]
 parts.append('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 320" width="320" height="320">')
 parts.append(f'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="{lighten(bg,.35)}"/><stop offset="100%" stop-color="{shade(bg,.72)}"/></linearGradient><clipPath id="clip"><rect x="8" y="8" width="304" height="304" rx="42"/></clipPath></defs>')
 parts.append('<g clip-path="url(#clip)"><rect width="320" height="320" fill="url(#g)"/>')
 # geometric character motifs in background
 motif=a['seed']%5
 if motif==0:
  for j in range(6):parts.append(f'<circle cx="{(j*93+21)%330}" cy="{(j*63+19)%260}" r="{16+j*4}" fill="none" stroke="#ffffff" stroke-opacity=".16" stroke-width="6"/>')
 elif motif==1:
  for j in range(6):parts.append(f'<path d="M {j*65-150} 0 L {j*65+25} 315" stroke="#ffffff" stroke-opacity=".14" stroke-width="17"/>')
 elif motif==2:
  for j in range(6):parts.append(f'<rect x="{(j*73)%308}" y="{(j*97)%240}" width="35" height="35" rx="7" transform="rotate(25 {(j*73)%308} {(j*97)%240})" fill="#ffffff" fill-opacity=".12"/>')
 elif motif==3:
  parts.append('<path d="M-40 212 Q60 114 175 201 T350 185 V340 H-40Z" fill="#ffffff" fill-opacity=".12"/>')
 else:
  for j in range(10):parts.append(f'<circle cx="{r.randrange(12,300)}" cy="{r.randrange(12,254)}" r="{r.randrange(2,11)}" fill="#ffffff" opacity=".16"/>')
 # neck, back, shoulders: varied garment silhouettes
 torso_top=241
 parts.append(ellipse(160,340,145,112,'#25283b','#302938',7))
 parts.append(linepath('M128 206 L128 267 Q160 293 192 267 L192 204 Z',shade(skin,.85)))
 bodytype=a['jacket']
 coat_edges=['M 9 323 Q 18 256 94 239 L130 224 Q160 256 190 224 L226 239 Q 300 256 311 323Z',
             'M -2 325 Q 24 248 117 230 Q160 267 203 230 Q299 248 322 325Z',
             'M 10 325 Q22 262 120 231 L160 259 L200 231 Q298 263 310 325Z',
             'M 2 326 Q18 251 114 224 L160 257 L206 224 Q302 250 320 326Z',
             'M 0 326 Q50 239 122 235 L160 248 L202 235 Q270 239 320 326Z']
 parts.append(linepath(coat_edges[bodytype],color,w=7))
 if bodytype==0:
  parts.append(linepath('M126 228 L160 255 L135 322 L84 243Z',lighten(color,.23),w=4));parts.append(linepath('M194 228 L160 255 L185 322 L238 243Z',shade(color,.88),w=4))
 elif bodytype==1:
  parts.append(linepath('M 116 234 Q160 260 204 234 L190 278 Q160 299 130 278Z',shade(color,.7),w=4))
 elif bodytype==2:
  for k in range(3):parts.append(f'<circle cx="160" cy="{268+k*22}" r="5" fill="#e5d3b4"/>')
 elif bodytype==3:
  parts.append(linepath('M126 229 L159 266 L194 229',"none",stroke=lighten(color,.58),w=10))
 else:
  parts.append(linepath('M127 234 L160 280 L193 234',shade(color,.73),w=8))
 # secondary neck accessory
 if a['accessory'] in [1,5]:
  parts.append(linepath('M128 247 Q160 272 193 247', '#eadab7',stroke='#302938',w=5))
 if a['accessory']==2:
  parts.append(linepath('M138 246 L159 283 L183 245', '#f1e0cd',stroke='#302938',w=4))
 if a['accessory']==7:
  parts.append('<path d="M116 260 Q160 280 203 260" stroke="#ffce5c" stroke-width="7" fill="none"/>')
 # silhouette hair at back
 # Back-hair length, hair tied up, or headscarf silhouettes for diverse women.
 if a['female'] and not a['hijab']:
  parts.append(linepath('M91 109 Q76 149 73 251 Q102 278 118 240 L120 132 Q164 75 211 136 L211 244 Q250 283 250 249 Q245 136 226 105Z',shade(hair,.81),w=6))
 if a['hijab']:
  scarf=COLORS[(a['seed']*3+7)%len(COLORS)]
  parts.append(linepath('M95 96 Q160 35 225 100 L246 265 Q160 283 73 265Z',shade(scarf,.82),w=6))
 else:
  parts.append(ellipse(160,126,74+a['hstyle']%4*2,94,shade(hair,.79),w=6))
 # ears (large/small variations)
 erx=10+a['age']%3*2
 parts.append(ellipse(90,163,erx,19,skin,w=4));parts.append(ellipse(230,163,erx,19,skin,w=4))
 # face different shapes
 shape=a['shape']
 faces=[
 'M 102 94 Q159 55 216 94 Q238 125 225 179 Q214 231 160 240 Q106 231 95 179 Q82 125 102 94Z',
 'M 115 89 Q160 63 206 89 Q239 120 221 185 Q207 233 159 240 Q112 228 98 185 Q82 119 115 89Z',
 'M 115 88 Q160 65 207 88 Q229 112 225 175 Q212 235 160 239 Q108 234 95 175 Q90 112 115 88Z',
 'M 111 93 Q161 68 211 93 Q237 117 220 183 Q205 220 161 232 Q116 219 99 183 Q80 119 111 93Z',
 'M 119 89 Q157 67 201 91 Q232 119 223 183 Q205 243 159 248 Q115 240 99 183 Q89 120 119 89Z',
 'M 105 91 Q160 60 212 91 Q244 137 224 194 Q207 228 159 234 Q111 229 95 194 Q76 135 105 91Z',
 'M 100 100 Q160 48 217 100 Q244 132 226 191 Q198 242 160 244 Q118 241 93 191 Q76 134 100 100Z'
 ]
 parts.append(linepath(faces[shape],skin,w=7))
 # face highlights + shade subtle
 parts.append('<path d="M113 152 Q112 196 138 215" stroke="#ffffff" stroke-opacity=".15" stroke-width="7" stroke-linecap="round" fill="none"/>')
 parts.append(f'<ellipse cx="113" cy="179" rx="18" ry="9" fill="#da6a70" opacity=".20"/><ellipse cx="207" cy="179" rx="18" ry="9" fill="#da6a70" opacity=".20"/>')
 # beard / jaw
 if a['beard']:
  parts.append(linepath('M104 198 Q118 236 157 239 Q198 235 217 196 Q206 221 178 221 Q159 233 141 221 Q114 221 104 198Z',hair,w=2))
 # nose styles
 if a['nose']==0:parts.append('<path d="M160 155 L153 183 Q162 188 171 183" stroke="#654d45" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" fill="none"/>')
 elif a['nose']==1:parts.append('<path d="M155 164 Q145 185 164 188" stroke="#704b3e" stroke-width="4" stroke-linecap="round" fill="none"/>')
 elif a['nose']==2:parts.append('<path d="M163 158 Q170 182 158 185" stroke="#704b3e" stroke-width="4" stroke-linecap="round" fill="none"/>')
 else:parts.append('<ellipse cx="162" cy="184" rx="7" ry="5" fill="'+shade(skin,.82)+'"/>')
 # eyes
 eyeY=148+a['eye']%3*3
 for k in [-1,1]:
  x=160+k*(25+a['shape']%3*2)
  if a['eye']==0:
   parts.append(ellipse(x,eyeY,10,10,'#fff9e9','#302938',3)); parts.append(ellipse(x+2,eyeY+1,4.8,6,EYE[a['seed']%4],'none',0))
  elif a['eye']==1:
   parts.append(f'<path d="M{x-11} {eyeY} Q{x} {eyeY-7} {x+11} {eyeY}" fill="none" stroke="#302938" stroke-width="5" stroke-linecap="round"/>')
   parts.append(ellipse(x,eyeY+1,3.5,4,'#302938','none',0))
  elif a['eye']==2:
   parts.append(ellipse(x,eyeY,10,7,'#fff9e9','#302938',3));parts.append(ellipse(x,eyeY+1,3.8,4.5,EYE[a['seed']%4],'none',0))
  elif a['eye']==3:
   parts.append(f'<path d="M{x-10} {eyeY} Q{x} {eyeY+10} {x+10} {eyeY}" fill="none" stroke="#302938" stroke-width="4"/>')
  else:
   parts.append(ellipse(x,eyeY,9,11,'#fff9e9','#302938',3));parts.append(ellipse(x+2,eyeY+2,4,6,EYE[a['seed']%4],'none',0))
  parts.append(f'<path d="M{x-13} {eyeY-19} Q{x} {eyeY-25-(a["age"]%2)*3} {x+13} {eyeY-18}" stroke="{shade(hair,.75)}" stroke-width="{5+a["age"]%3}" stroke-linecap="round" fill="none"/>')
 # mouth: different smiles
 mouth = a['seed']%7
 if mouth==0:parts.append('<path d="M144 206 Q160 224 178 205" stroke="#672e35" stroke-width="5" stroke-linecap="round" fill="none"/>')
 if mouth==1:parts.append('<path d="M145 209 Q159 203 177 209" stroke="#672e35" stroke-width="5" stroke-linecap="round" fill="none"/>')
 if mouth==2:parts.append('<path d="M142 205 Q160 214 180 204 Q177 229 161 230 Q148 229 142 205Z" fill="#6e333d" stroke="#302938" stroke-width="3"/><path d="M145 210 Q160 215 176 209" stroke="#ffffff" stroke-width="5"/>')
 if mouth==3:parts.append('<path d="M143 215 Q158 207 179 218" stroke="#723d45" stroke-width="5" fill="none"/>')
 if mouth==4:parts.append(ellipse(161,211,8,11,'#733e43','#302938',3))
 if mouth==5:parts.append('<path d="M147 209 L175 209" stroke="#723d45" stroke-width="5" stroke-linecap="round"/>')
 if mouth==6:parts.append('<path d="M142 208 Q155 222 179 205" stroke="#723d45" stroke-width="5" stroke-linecap="round" fill="none"/>')
 if a['mustache']:
  parts.append(linepath('M130 196 Q141 183 159 197 Q175 182 189 196 Q174 207 159 199 Q143 209 130 196Z',hair,w=3))
 if a['freckles']:
  for xx,yy in [(119,174),(128,178),(136,173),(184,173),(193,178),(201,174)]:parts.append(f'<circle cx="{xx}" cy="{yy}" r="2.4" fill="{shade(skin,.66)}"/>')
 if a['senior']:
  # Crow's feet, forehead creases, smile folds and under-eye shading visibly age a face.
  for x in [109,117,203,211]:
   parts.append(f'<path d="M{x-7} 162 l9 3 M{x-7} 168 l9 3" stroke="#76564a" opacity=".48" stroke-width="2.7" fill="none"/>')
  for y in [118,125,132]:
   parts.append(f'<path d="M133 {y} Q160 {y+4} 188 {y}" stroke="#76564a" opacity=".34" stroke-width="2" fill="none"/>')
  parts.append('<path d="M114 176 Q113 197 128 202 M205 177 Q207 194 191 203" stroke="#76564a" stroke-width="2.7" opacity=".45" fill="none"/>')
 if a['age']>=3:
  parts.append('<path d="M102 164 L123 165 M196 165 L217 164" stroke="#8b5a48" opacity=".28" stroke-width="2"/>')
 # front hair overlays, silhouette variation (13 distinct styles)
 hstyle=a['hstyle']
 hairstyles=[
 'M91 130 Q81 74 119 75 Q171 39 211 75 Q235 101 224 133 L204 117 L197 94 Q171 118 137 101 L116 128Z',
 'M92 120 Q85 75 130 63 Q184 49 224 96 L218 133 L190 96 L158 108 L130 84 L106 122Z',
 'M89 131 Q93 70 139 72 Q160 47 194 65 Q231 88 226 131 L210 108 L192 114 L174 92 L154 115 L133 104 L110 131Z',
 'M92 119 Q100 52 169 59 Q235 65 228 119 Q197 101 168 92 Q126 112 92 119Z',
 'M93 132 Q82 62 156 65 Q203 45 224 96 L218 129 Q201 104 179 107 Q143 137 113 110Z',
 'M91 120 Q96 71 151 74 Q187 54 226 93 L229 144 Q216 129 207 119 L200 98 Q155 120 131 111Z',
 'M91 131 Q91 65 160 60 Q229 68 227 132 L213 100 Q177 88 158 110 Q119 89 105 124Z',
 'M97 116 Q85 69 148 73 Q183 64 213 86 L224 111 Q190 114 158 88 Q123 118 97 116Z',
 'M94 130 Q93 76 143 70 Q184 50 225 93 L226 130 L196 109 Q163 123 151 101 Q122 122 105 132Z',
 'M90 128 Q95 84 140 66 Q207 57 225 116 Q188 79 155 104 Q120 111 90 128Z',
 'M91 128 Q85 85 132 72 Q159 50 192 73 Q217 73 227 125 L210 107 L177 119 L146 101 L121 127Z',
 'M95 132 Q83 87 115 70 Q170 50 207 79 Q227 89 223 129 Q188 101 161 99 Q132 116 111 133Z',
 'M94 115 Q104 68 143 68 Q171 52 207 76 Q225 94 225 117 L210 108 Q195 113 176 99 Q143 116 120 107Z'
 ]
 if a['hijab']:
  scarf=COLORS[(a['seed']*3+7)%len(COLORS)]
  parts.append(linepath('M92 121 Q96 65 159 64 Q223 65 229 121 L214 153 Q208 104 195 95 Q160 80 126 100 Q111 120 107 159Z',scarf,w=5))
  parts.append(linepath('M108 149 Q103 212 127 235 L103 279 L76 257 Q70 169 92 116Z',shade(scarf,.75),w=4))
 else:
  parts.append(linepath(hairstyles[hstyle],hair,w=5))
 # extra bangs/curls/long hair
 if not a['hijab'] and hstyle in [2,5,10]:
  parts.append(linepath('M103 113 Q88 138 105 172 L108 127 M215 119 Q235 151 219 181','none',stroke=hair,w=13))
 if not a['hijab'] and hstyle in [1,7,11]:
  for dx in [115,140,164,188]:parts.append(f'<path d="M{dx} 86 Q{dx+9} 102 {dx-2} 115" fill="none" stroke="{hair}" stroke-width="10" stroke-linecap="round"/>')
 if not a['hijab'] and hstyle in [0,3,9]:parts.append('<path d="M104 86 Q165 53 213 95" stroke="'+lighten(hair,.2)+'" stroke-width="5" opacity=".45" fill="none"/>')
 # hats
 if a['hat'] and not a['hijab']:
  if a['seed']%3==0:
   parts.append(linepath('M97 91 L102 60 Q160 35 217 62 L222 91 Q160 104 97 91Z',shade(color,.66),w=5));parts.append(linepath('M72 93 Q153 112 246 90 Q231 112 160 115 Q97 115 72 93Z',color,w=4))
  elif a['seed']%3==1:
   parts.append(linepath('M107 81 Q112 33 160 32 Q211 33 217 83 Q160 99 107 81Z',color,w=5));parts.append(linepath('M88 86 Q161 103 234 86 L232 106 Q161 114 90 106Z',shade(color,.69),w=4))
  else:
   parts.append(linepath('M103 80 Q160 18 217 80 L223 93 Q162 110 97 93Z',shade(color,.75),w=5));parts.append(linepath('M88 100 Q160 111 233 100','none',stroke=lighten(color,.45),w=9))
 # glasses spectacles with slight gradient clear lenses
 if a['eyewear']:
  glasses=['#262938','#6d4c37','#3a5261'][a['seed']%3]
  if a['seed']%4==0:
   for x in [132,190]:parts.append(f'<rect x="{x-26}" y="139" width="52" height="32" rx="11" fill="#ecf8fa" fill-opacity=".16" stroke="{glasses}" stroke-width="6"/>')
  elif a['seed']%4==1:
   for x in [132,190]:parts.append(f'<circle cx="{x}" cy="155" r="22" fill="#ecf8fa" fill-opacity=".16" stroke="{glasses}" stroke-width="6"/>')
  elif a['seed']%4==2:
   for x in [132,190]:parts.append(f'<path d="M{x-24} 144 L{x+24} 144 L{x+19} 172 Q{x} 181 {x-20} 172Z" fill="#ecf8fa" fill-opacity=".14" stroke="{glasses}" stroke-width="6"/>')
  else:
   for x in [132,190]:parts.append(f'<rect x="{x-25}" y="143" width="50" height="27" rx="6" fill="#ecf8fa" fill-opacity=".16" stroke="{glasses}" stroke-width="6"/>')
  parts.append(f'<path d="M157 153 Q160 149 165 153" stroke="{glasses}" stroke-width="6" fill="none"/>')
 if a['earrings']:
  parts.append('<circle cx="89" cy="188" r="7" fill="#ffd97e" stroke="#4b3e3c" stroke-width="3"/><circle cx="232" cy="188" r="7" fill="#ffd97e" stroke="#4b3e3c" stroke-width="3"/>')
 # identity chip in lower right (within portrait)
 parts.append(f'<circle cx="276" cy="276" r="25" fill="{shade(color,.52)}" stroke="#302938" stroke-width="5"/>')
 marks=['★','♫','✦','☀','✿','◆','✳','✚']
 # SVG fonts unicode dingbat are risky. use vector circles/spokes motif
 parts.append('<circle cx="276" cy="276" r="8" stroke="#fff9ec" fill="none" stroke-width="4"/>')
 for ang in range(0,360,90):
  x1=276+math.cos(math.radians(ang))*13;y1=276+math.sin(math.radians(ang))*13
  x2=276+math.cos(math.radians(ang))*17;y2=276+math.sin(math.radians(ang))*17
  parts.append(f'<path d="M{x1:.1f} {y1:.1f} L{x2:.1f} {y2:.1f}" stroke="#fff9ec" stroke-width="3"/>')
 parts.append('</g><rect x="5" y="5" width="310" height="310" rx="44" fill="none" stroke="#272735" stroke-width="9"/></svg>')
 return ''.join(parts)

def main():
 allprofiles=[]
 for i in range(144):
  p=generate_profile(i)
  out=PORTRAITS/f'caller_{i+1:03}.png'
  cairosvg.svg2png(bytestring=render_svg(p).encode('utf-8'),write_to=str(out),output_width=256,output_height=256)
  del p['_art']
  allprofiles.append(p)
 with (BASE/'caller_profiles.json').open('w',encoding='utf-8') as f:json.dump({'callers':allprofiles},f,indent=2,ensure_ascii=False)
 print(f'Created {len(allprofiles)} unique caller portraits + complete profiles: {BASE}')

if __name__=='__main__':main()
