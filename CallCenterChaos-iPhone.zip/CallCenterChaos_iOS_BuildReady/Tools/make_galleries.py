#!/usr/bin/env python3
"""Render Arabic overview sheets from the actual 144 PNG caller assets; no fonts are bundled."""
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parents[1]
profiles=json.loads((root/'Assets/Resources/Callers/caller_profiles.json').read_text(encoding='utf-8'))['callers']
previews=root/'Previews';previews.mkdir(exist_ok=True)
fontpath='/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf'
if not Path(fontpath).exists():
 fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
namefont=ImageFont.truetype(fontpath,16)
tagfont=ImageFont.truetype(fontpath,15)
headerfont=ImageFont.truetype(fontpath,28)
for page in range(4):
 cols=6;rows=6;cellw=175;cellh=203; pad=12
 canvas=Image.new('RGB',(cols*cellw+2*pad,rows*cellh+120),(20,27,38)); d=ImageDraw.Draw(canvas)
 d.text((canvas.width-20,14),f'شخصيات اللعبة | المجموعة {page+1} من 4',font=headerfont,fill='#f7f5f0',anchor='ra',direction='rtl')
 for j,p in enumerate(profiles[page*36:page*36+36]):
  x=pad+(j%cols)*cellw;y=85+(j//cols)*cellh
  img=Image.open(root/'Assets/Resources'/ (p['portrait']+'.png')).convert('RGB').resize((145,145))
  canvas.paste(img,(x,y));
  tag=('امرأة' if p['gender']=='female' else 'رجل')+f' | {p["age"]} سنة'
  d.text((x+5,y+148),p['displayName'],font=namefont,fill='#ffffff',direction='rtl',anchor='la')
  d.text((x+5,y+170),tag,font=tagfont,fill='#ffcc82',direction='rtl',anchor='la')
 out=previews/f'Callers_{page+1:02}.jpg'
 canvas.save(out,quality=90)
 print(out.name,round(out.stat().st_size/1024),'KiB')
