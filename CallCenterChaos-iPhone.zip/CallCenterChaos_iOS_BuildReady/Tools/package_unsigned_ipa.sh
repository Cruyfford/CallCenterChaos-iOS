#!/usr/bin/env bash
set -euo pipefail
# Exports a non-installable-until-signed IPA from Unity's Xcode project.
# Needs a macOS machine with Xcode and iOS SDK, does NOT sign with an Apple certificate.
ROOT="${1:-build/iOS/CallCenterChaos}"
OUT="${2:-output/CallCenterChaos-UNSIGNED.ipa}"
if [[ "$(uname)" != "Darwin" ]]; then echo 'This step needs macOS/Xcode.' >&2; exit 2; fi
if ! command -v xcodebuild >/dev/null 2>&1; then echo 'Xcode not available.' >&2; exit 2; fi
PROJECT="$ROOT/Unity-iPhone.xcodeproj"
if [[ ! -d "$PROJECT" ]]; then echo "Missing Unity Xcode project: $PROJECT" >&2; exit 2; fi
DERIVED="${RUNNER_TEMP:-/tmp}/ccc-ios-derived"
mkdir -p "$(dirname "$OUT")"
xcodebuild -project "$PROJECT" \
  -scheme Unity-iPhone \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' \
  build
APP="$DERIVED/Build/Products/Release-iphoneos/Unity-iPhone.app"
if [[ ! -d "$APP" ]]; then echo "Built application not found: $APP" >&2; exit 3; fi
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/Payload"
ditto "$APP" "$STAGE/Payload/Unity-iPhone.app"
(cd "$STAGE" && ditto -c -k --keepParent Payload "$(pwd)/temp.ipa")
mv "$STAGE/temp.ipa" "$OUT"
unzip -t "$OUT" >/dev/null
printf '\nCreated unsigned IPA: %s\n' "$OUT"
printf 'It is NOT installable on a stock iPhone until correctly signed.\n'
