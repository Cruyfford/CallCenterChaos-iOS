from pathlib import Path
p=Path(__file__).resolve().parents[1]/'Assets/Scripts/OfficePrototype.cs'
s=p.read_text()
s=s.replace('private enum ScreenPage { World, Desktop, Phone, Script, RemotePC, Paint, Camera, Review }','private enum ScreenPage { World, Desktop, Phone, Directory, Script, RemotePC, Paint, Camera, Review }')
s=s.replace('    private string caller = "", callerLine = "", eventMessage = "Welcome to your first shift.";','    private string caller = "", callerLine = "", eventMessage = "Welcome to your first shift.";\n    private CallerRoster roster;\n    private CallerProfile activeProfile;\n    private int directoryPage = 0;')
s=s.replace('    private readonly string[] callers = {"Mia Moon", "Leo Pixel", "Benny Banana", "Nora Neon", "Max Marshmallow", "Zara Zoom"};\n    private readonly string[] greetings = {\n        "Hello! My imaginary computer keeps dancing. What is going on?",\n        "Is this the office of unusual technical problems?",\n        "I need help with my cartoon gift-card collection.",\n        "My virtual desktop is upside down again!"\n    };\n','')
s=s.replace('        Application.targetFrameRate = 60;','        Application.targetFrameRate = 60;\n        roster = new CallerRoster();')
s=s.replace('if (!(row == 0 && col == 1)) MakeCoworker(new Vector3(x, 0, z-2f), row*3+col);','if (!(row == 0 && col == 1)) StaffStudio.Build(new Vector3(x, 0, z-2f), row*3+col);')
s=s.replace('MakeCoworker(new Vector3(-5.6f, 0, 4.4f), 5, true);','StaffStudio.Build(new Vector3(-5.6f, 0, 4.4f), 5, true);')
start=s.index('    private void MakeCoworker(')
end=s.index('    private void Choice(int choice)',start)
s=s[:start]+'''    private void NewCall()
    {
        BeginCall(roster == null ? null : roster.GetRandom());
    }

    private void BeginCall(CallerProfile selected)
    {
        if (selected == null)
        {
            eventMessage = "No caller data loaded. Re-run the character generator.";
            page = ScreenPage.Phone;
            return;
        }
        callCount++;
        activeProfile = selected;
        caller = selected.displayName;
        callerLine = selected.greeting;
        spokenText = "";
        customerReply = callerLine;
        trust = Mathf.Clamp(selected.patience, 27, 65);
        callActive = true;
        VoiceBridge.Speak(customerReply);
        page = ScreenPage.Phone;
    }

''' + s[end:]
s=s.replace('customerReply = trust > 75 ? "Okay, that seems reasonable!" : trust < 25 ?\n                     "No thank you. This is too strange!" : "Hmm... explain that a bit more.";','customerReply = activeProfile == null ? "Hmm... explain that a bit more." :\n                         trust > 75 ? activeProfile.highTrustReply :\n                         trust < 25 ? activeProfile.lowTrustReply : activeProfile.mediumTrustReply;')
s=s.replace('customerReply = trust >= 75 ? "You sound friendly. I might trust you." : "All right, I am listening.";','customerReply = activeProfile == null ? "All right, I am listening." :\n                        trust >= 75 ? activeProfile.highTrustReply : activeProfile.mediumTrustReply;')
s=s.replace('            case ScreenPage.Phone: DrawPhone(); break;','            case ScreenPage.Phone: DrawPhone(); break;\n            case ScreenPage.Directory: DrawDirectory(); break;')
s=s.replace('string[] items = {"PHONE", "SCRIPT", "REMOTE PC", "PAINT", "CAMERA", "BOSS REVIEW"};','string[] items = {"PHONE", "SCRIPT", "REMOTE PC", "PAINT", "CAMERA", "BOSS REVIEW", "144 CALLERS"};')
s=s.replace('for(int i=0;i<items.Length;i++)\n        {\n            int row=i/3,col=i%3;\n            if(Btn(new Rect(235+col*391,290+row*184,343,128),items[i]))','for(int i=0;i<items.Length;i++)\n        {\n            int row=i/4,col=i%4;\n            if(Btn(new Rect(228+col*294,286+row*190,254,128),items[i]))')
s=s.replace('                else ReviewDay();','                else if(i==5) ReviewDay();\n                else { directoryPage = 0; page = ScreenPage.Directory; }')
start=s.index('    private void DrawPhone()')
end=s.index('    private void DrawScript()',start)
s=s[:start]+'''    private void DrawPortrait(CallerProfile profile, Rect rect)
    {
        Texture2D portrait = roster == null ? null : roster.Portrait(profile);
        if (portrait != null)
        {
            GUI.DrawTexture(rect, portrait, ScaleMode.ScaleToFit);
        }
        else
        {
            DrawRect(rect, new Color(.17f,.23f,.28f));
            GUI.Label(rect, "?", headerStyle);
        }
    }

    private void DrawPhone()
    {
        Panel("PHONE  |  FICTIONAL AI-STYLE CALLS");
        if(!callActive)
        {
            Label(new Rect(225,200,1000,52),"NO ACTIVE CALL", true);
            Label(new Rect(226,260,1090,54),"144 fictional callers with portraits, moods, jobs and unique introductions.");
            if(Btn(new Rect(370,344,840,95),"ANSWER RANDOM CALL")) NewCall();
            if(Btn(new Rect(370,467,840,95),"BROWSE 144 CALLERS")) { directoryPage=0; page=ScreenPage.Directory; }
            if(Btn(new Rect(555,650,470,78),"BACK TO DESKTOP")) page=ScreenPage.Desktop;
            return;
        }
        DrawPortrait(activeProfile,new Rect(219,198,217,217));
        Label(new Rect(476,199,806,52),caller, true);
        GUI.Label(new Rect(476,253,802,72),
            activeProfile == null ? "Incoming caller" :
            activeProfile.personality.ToUpperInvariant()+"  |  "+activeProfile.occupation,smallStyle);
        Label(new Rect(477,328,700,45),"CALLER TRUST");
        DrawRect(new Rect(477,385,690,28),new Color(.22f,.24f,.28f));
        DrawRect(new Rect(477,385,690*trust/100f,28),trust>=65?new Color(.18f,.76f,.49f):new Color(.94f,.60f,.22f));
        Label(new Rect(1203,370,120,60),trust+"%",true);
        GUI.Box(new Rect(210,447,1140,114),GUIContent.none,darkBoxStyle);
        GUI.Label(new Rect(230,463,1098,96),customerReply,bodyStyle);
        if(Btn(new Rect(221,583,356,74),"BE FRIENDLY")) Choice(0);
        if(Btn(new Rect(597,583,356,74),"ASK QUESTIONS")) Choice(1);
        if(Btn(new Rect(973,583,356,74),"RUSH THE CALL")) Choice(2);
        if(Btn(new Rect(221,673,353,66),"SPEAK (MIC)")) VoiceBridge.Listen(gameObject.name);
        if(Btn(new Rect(597,673,353,66),"REPEAT AUDIO")) VoiceBridge.Speak(customerReply);
        if(Btn(new Rect(973,673,353,66),"END CALL")) EndCall();
        GUI.Label(new Rect(223,758,1100,65),"You: "+spokenText,smallStyle);
    }

    private void DrawDirectory()
    {
        Panel("CHARACTER DIRECTORY  |  " + (roster == null ? 0 : roster.Count) + " UNIQUE CALLERS");
        if (roster == null || roster.Count == 0)
        {
            Label(new Rect(235,280,1040,80),"No caller portraits found. Run the supplied generator.");
            return;
        }
        const int itemsPerPage = 18;
        int totalPages = (roster.Count + itemsPerPage-1) / itemsPerPage;
        directoryPage = Mathf.Clamp(directoryPage,0,totalPages-1);
        GUI.Label(new Rect(218,184,1090,38),
            "TAP ANY PORTRAIT TO START A TEST CALL  -  ALL NAMES AND STORIES ARE FICTIONAL",smallStyle);
        for (int j=0;j<itemsPerPage;j++)
        {
            int idx=directoryPage*itemsPerPage+j;
            CallerProfile info=roster.Get(idx);
            if(info==null)break;
            int col=j%6,row=j/6;
            float x=228+col*195, y=238+row*164;
            GUI.Box(new Rect(x-7,y-7,179,153),GUIContent.none,darkBoxStyle);
            DrawPortrait(info,new Rect(x,y,105,105));
            GUI.Label(new Rect(x+111,y+2,54,24),"#"+(idx+1),smallStyle);
            GUI.Label(new Rect(x+111,y+28,61,62),info.personality,smallStyle);
            if(Btn(new Rect(x,y+108,166,37),info.displayName)) BeginCall(info);
        }
        if(Btn(new Rect(240,757,275,60),"PREVIOUS") && directoryPage>0) directoryPage--;
        Label(new Rect(664,759,290,57),"PAGE "+(directoryPage+1)+" / "+totalPages);
        if(Btn(new Rect(1044,757,275,60),"NEXT") && directoryPage<totalPages-1) directoryPage++;
    }

''' + s[end:]
p.write_text(s,encoding='utf-8')
print('patched',p)
