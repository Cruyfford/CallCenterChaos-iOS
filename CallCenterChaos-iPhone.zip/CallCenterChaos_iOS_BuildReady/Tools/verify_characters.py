#!/usr/bin/env python3
"""Asset-integrity check; does not substitute for Unity Editor or iOS device tests."""
from pathlib import Path
from PIL import Image
import json,hashlib,re
root=Path(__file__).resolve().parents[1]
assets=root/'Assets/Resources/Callers'
profiles=json.loads((assets/'caller_profiles.json').read_text('utf-8'))['callers']
assert len(profiles)==144, 'exactly 144 caller profiles expected'
assert len({p['id'] for p in profiles})==144, 'ids duplicated'
assert len({p['displayName'] for p in profiles})==144, 'names duplicated'
assert len({p['greeting'] for p in profiles})==144, 'greetings duplicated'
required=['id','displayName','portrait','personality','occupation','topic','greeting','dialogueHint','highTrustReply','mediumTrustReply','lowTrustReply','patience','voicePitch']
hashes=set()
for p in profiles:
 assert all(k in p and p[k]!='' for k in required),f'Missing profile data: {p["id"]}'
 image= root/'Assets/Resources'/(p['portrait']+'.png')
 assert image.exists(),f'Missing portrait {image}'
 with Image.open(image) as im:
  assert im.size == (256,256) and im.mode in ('RGBA','RGB'),f'bad portrait: {image}'
 digest=hashlib.sha256(image.read_bytes()).digest()
 assert digest not in hashes,f'identical portrait bytes: {image}'
 hashes.add(digest)
core=(root/'Assets/Scripts/OfficePrototype.cs').read_text()
assert 'case ScreenPage.Directory: DrawDirectory();' in core
assert 'StaffStudio.Build' in core
assert 'BeginCall(info)' in core
assert 'roster.Portrait(profile)' in core
assert not re.search(r'private void MakeCoworker\(',core)
assert 'int staffIndex=0;' in core
print('PASS: 144 unique profiles, portrait files, introduction texts and hashes')
print('PASS: Unity phone UI / directory / office staff integration references present')
print('LIMITATION: Unity compilation and on-device performance NOT tested')
